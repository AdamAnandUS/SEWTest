﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmartEnergyWaterTest
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        /// <summary>
        /// The click event starts a background worker process and also gets the input file from the user.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonLoadTestData_Click(object sender, EventArgs e)
        {
            BackgroundWorker bgw = new BackgroundWorker();
            bgw.DoWork += Bgw_DoWork;
            bgw.ProgressChanged += Bgw_ProgressChanged;
            bgw.RunWorkerCompleted += Bgw_RunWorkerCompleted;
            bgw.WorkerReportsProgress = true;
            bgw.WorkerSupportsCancellation = false; // Not supporting cancel operation for now.

            List<string> testData = new List<string>();

            OpenFileDialog fd = new OpenFileDialog();
            fd.DefaultExt = "txt";
            fd.Filter = "Text files (*.txt)|*.txt";
            fd.Multiselect = false;
            if (fd.ShowDialog() == DialogResult.OK)
            {
                using (StreamReader sr = new StreamReader(fd.FileName))
                {
                    string eachLine;
                    while ((eachLine = sr.ReadLine()) != null)
                    {
                        if (String.IsNullOrEmpty(eachLine) == false)
                        {
                            testData.Add(eachLine);
                        }
                    }
                }
                textBoxUserMessage.Text = "";
                richTextBoxInfo.Clear();
            }

            bgw.RunWorkerAsync(testData);
        }

        /// <summary>
        /// The background work is completed and the results are displayed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bgw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            List<StringInfo> results = e.Result as List<StringInfo>;
            int recCount = 0;
            foreach(StringInfo eachResult in results)
            {
                recCount++;
                string toShow = recCount.ToString() + ". - " + eachResult.KeyString + " - " + eachResult.KeyString.Length.ToString() + "\n" ;
                richTextBoxInfo.AppendText(toShow);
            }
        }

        /// <summary>
        /// The progress is being reported.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bgw_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            textBoxUserMessage.Text = e.UserState.ToString() ;
        }

        /// <summary>
        /// The main time consuming work is done here.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bgw_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;

            List<string> testData = e.Argument as List<string>;  

            List<StringInfo> stringInfos = new List<StringInfo>();
            int loopIndex = -1;
            int totRecs = testData.Count;
            foreach (string eachString in testData)
            {
                loopIndex++;

                // This code is need if we support cancellation. For now it is not supported.
                //if ((worker.CancellationPending == true))
                //{
                //    e.Cancel = true;
                //    break;
                //}

                string togoMessage = "Record " + (loopIndex + 1) + " of " + totRecs.ToString() + ".";
                worker.ReportProgress((100 * loopIndex) / totRecs, togoMessage);

                StringInfo eachSInfo = FindAllPossibleSubStringsInRightOrder(eachString, testData);
                if (eachSInfo.SubStrings.Count > 0) // Only if Substrings are present then we need to consider it.
                {
                    stringInfos.Add(eachSInfo);
                }
            }

            // Here we are validating and making sure that each string in fact can be constructed by the substrings.
            List<StringInfo> validStringInfos = new List<StringInfo>();
            foreach (StringInfo eachSInfo in stringInfos)
            {
                if (IsStringMadeFromSubstrings(eachSInfo.KeyString, eachSInfo.SubStrings))
                {
                    validStringInfos.Add(eachSInfo);
                }
            }

            List<StringInfo> orderedFinalResults = (from a in validStringInfos
                                                    orderby a.KeyString.Length
                                                    select a).ToList<StringInfo>();

            orderedFinalResults.Reverse();

            e.Result = orderedFinalResults;
            worker.ReportProgress(100, "Task Completed.");
        }

        /// <summary>
        /// This is the key place where eachtime we find a substring then we empty it.
        /// Care should be taken that we eliminate the substring with max length first.
        /// That's the reason the SubString List should be ordered in the right way.
        /// </summary>
        /// <param name="keyString"></param>
        /// <param name="containsStrings"></param>
        /// <returns></returns>
        private bool IsStringMadeFromSubstrings(string keyString, List<string> containsStrings)
        {
            //List<string> startswithList = containsStrings.Where(x => keyString.StartsWith(x) == true).ToList();

            string toCheckString = keyString;
            foreach(string eachString in containsStrings)
            {
                toCheckString = toCheckString.Replace(eachString, "");
            }

            if (toCheckString.Length > 0)
                return false;
            else
                return true;
        }

        /// <summary>
        /// This function finds all the small strings in the keystring.
        /// It orders it such that the substring with max length is on the top.
        /// </summary>
        /// <param name="keyString"></param>
        /// <param name="allStrings"></param>
        /// <returns></returns>
        private StringInfo FindAllPossibleSubStringsInRightOrder(string keyString, List<string> allStrings)
        {
            List<string> childStrings = (from a in allStrings
                                         where keyString.Contains(a) && keyString != a
                                         orderby a.Length
                                         select a ).ToList<string>();

            childStrings.Reverse();

            StringInfo stringInfo = new StringInfo(keyString, childStrings);
            return stringInfo;
        }


    }

}
