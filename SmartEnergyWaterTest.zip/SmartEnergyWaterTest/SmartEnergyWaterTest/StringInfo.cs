﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartEnergyWaterTest
{
    /// <summary>
    /// This class simply stores the main string and all the matching substrings that are found in the main list.
    /// </summary>
    public class StringInfo
    {
        public string KeyString { get; }
        public List<string> SubStrings { get; }
        public StringInfo(string inKeyString, List<string> inSubStrings)
        {
            KeyString = inKeyString;
            SubStrings = inSubStrings;
        }
    }
}
